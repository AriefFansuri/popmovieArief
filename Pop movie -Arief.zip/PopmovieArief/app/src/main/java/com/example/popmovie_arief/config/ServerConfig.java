package com.example.popmovie_arief.config;

public class ServerConfig {
    public static final String URL_BASE = "https://www.themoviedb.org/";
    public static final String API_ENDPOINT = URL_BASE;
}
